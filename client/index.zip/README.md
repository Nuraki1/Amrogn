# Some Clarifiction about the compoents in the react app

  - compoents list

      - App.jsx
      - cart.jsx
      - cartDropdown.jsx
      - categories
      - example
      - foodCard
      - footer
      - front
      - localizationToggle
      - menuList
      - popularMenu
      - spinningLogos
      - themeToggle
      - trial